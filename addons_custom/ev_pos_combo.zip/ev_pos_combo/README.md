# IZI Pos Promotion Combo

Module cấu hình bán combo trên pos