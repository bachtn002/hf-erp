odoo.define('ev_pos_hide_product.DB', function(require){
	"use strict"

	const PosDB = require('point_of_sale.DB');

	PosDB.include({

		search_product_in_category: function(category_id, query){
			let products = this._super.apply(this, arguments);
			let res = products.filter((item)=>{
				return !item.x_is_hide_on_list_of_pos;
			});
			return res;
		},

		get_product_by_category: function(category_id){
			let products = this._super.apply(this, arguments);
			let res = products.filter((item)=>{
				return !item.x_is_hide_on_list_of_pos;
			});
			return res;
		}

	})

	return PosDB;

})
