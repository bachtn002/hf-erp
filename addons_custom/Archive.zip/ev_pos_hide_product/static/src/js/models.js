odoo.define('ev_pos_hide_product.models', function(require){
	"use strict"

	const models = require('point_of_sale.models');


	models.load_fields('product.product', ['x_is_hide_on_list_of_pos']);


	return models;

});
