# IZI Pos Hide Product On Pos

Hide product on pos but still sell it