# -*- coding: utf-8 -*-
{
    'name': "ERPVIET Hide Product On Pos",

    'summary': """
      Allow hide product in product list of pos ui, but it is still loaded.
    """,
    'description': """""",

    'author': "ERPVIET",
    'website': "http://www.izisolution.com",

    'category': 'Point of sale',
    'version': '0.1',

    'depends': ['point_of_sale'],

    'data': [
        'views/assets.xml',
        'views/product_template.xml',
    ],
}
