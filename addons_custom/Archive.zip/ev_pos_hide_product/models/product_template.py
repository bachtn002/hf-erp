# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    x_is_hide_on_list_of_pos = fields.Boolean(
            string='Hide on product list of post', 
            default=False)

