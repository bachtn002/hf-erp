# -*- coding: utf-8 -*-

from . import customer_point_history
from . import customer_rank
from . import customer_rank_history
from . import loyalty_program
from . import res_partner
from . import pos_order

