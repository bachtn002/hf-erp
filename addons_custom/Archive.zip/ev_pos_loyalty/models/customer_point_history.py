# -*- coding: utf-8 -*-
from odoo import models, fields, api
from calendar import monthrange
import calendar
from dateutil.relativedelta import relativedelta


class CustomerPointHistory(models.Model):
    _name = 'customer.point.history'
    _order = 'create_date ASC'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Customer point history'

    partner_id = fields.Many2one('res.partner', string="Partner")
    point = fields.Float(string="Point")
    month_expire = fields.Integer('Month Expire')
    expire_date = fields.Date('Expire date')
    state = fields.Selection([
        ('available', 'Available'),
        ('expired', 'Expired')], string="State")
    
    def check_point_customer(self):
        date = fields.Date.today()
        customer_point_history_ids = self.search([('state','=','available')])
        for customer_point_hístory in customer_point_history_ids:
            partner_id = customer_point_hístory.partner_id
            month = customer_point_hístory.month_expire
            expire_date = date + relativedelta(months=month)
            expire_date = self.get_last_day_of_month(expire_date)
            if customer_point_hístory.expire_date == date:
                customer_point_hístory.state = 'expired'
                partner_id.loyalty_points = 0
                self.env['customer.point.history'].create({
                    'partner_id': partner_id.id,
                    'point': 0,
                    'expire_date': expire_date,
                    'state': 'available',
                    'month_expire': month
                })

    def get_last_day_of_month(expire_date):
        year = expire_date.year
        month = expire_date.month
        month_range = calendar.monthrange(year, month)
        date = expire_date.strftime('%Y-%m-') + str(month_range[1])
        return date

