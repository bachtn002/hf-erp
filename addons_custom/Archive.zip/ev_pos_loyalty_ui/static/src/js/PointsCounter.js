odoo.define('ev_pos_loyalty_ui.PointsCounter', function(require){
	"use strict"

	const core = require('web.core');
	const Counter = require('pos_loyalty.PointsCounter');
	const Registries = require('point_of_sale.Registries');

	const _t = core._t;

	class PointsCounter extends Counter{

		get_points_total(){
			let total = Counter.prototype.get_points_total.call(this);
			let won = Counter.prototype.get_points_won.call(this);
			let spent = Counter.prototype.get_points_spent.call(this);
			return total - won + spent;
		}

		getCurrentCustomerRank(){
			let customer = this.env.pos.get_client();
			if(customer.x_rank_id && customer.x_rank_id.length === 2){
				return this.env.pos.db.getCustomerRankById(customer.x_rank_id[0]);
			}
			return false;
		}

		getCurrentCustomerRankDiscountText(){
			let rank = this.getCurrentCustomerRank();
			if(!rank){
				return _t('No rank');
			}
			return rank.name + '/' + rank.discount + '%';
		}
	}

	Registries.Component.add(PointsCounter);

	return PointsCounter;

});
