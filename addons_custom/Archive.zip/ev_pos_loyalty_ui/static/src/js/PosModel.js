odoo.define('ev_pos_loyalty_ui.PosModel', function(require){
	"use strict"

	const models = require('point_of_sale.models');


	const _superPosModel = models.PosModel;
	models.PosModel = _superPosModel.extend({
		_save_to_server: function(orders, options){
			let res = _superPosModel.prototype._save_to_server.call(this, orders, options);
			this._sync_orders_customer_rank(orders);
			return res;
		},
		_sync_orders_customer_rank: function(orders){
			let self = this;
			orders.forEach((order)=>{
				if(!order.data.partner_id)
					return;
				self._sync_customer_rank(order.data.partner_id);
			})
		},
		_sync_customer_rank: function(partner_id){
			let domain = [['id', '=', partner_id]];
			let fields = ['x_rank_id'];
			let args = [domain, fields];
			let self = this;
			this.rpc({
				model: 'res.partner',
				method: 'search_read',
				args: args,
			}).then((response)=>{
				if(!response || response && response.length == 0)
					return;
				let partner = self.db.get_partner_by_id(response[0].id);
				partner.x_rank_id = response[0].x_rank_id;
				self.db.add_partners([partner]);
			});
		}
	});
	return models;

});
