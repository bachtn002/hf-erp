odoo.define('ev_pos_loyalty_ui.DB', function(require){
	"use strict"

	const PosDB = require('point_of_sale.DB');

	PosDB.include({

		saveCustomerRanks: function(ranks){
      this.save('customer_ranks', ranks);
		},

		getCustomerRanks: function(){
      return this.load('customer_ranks', []);
		},

		getCustomerRankById: function(id){
      let ranks = this.getCustomerRanks();
			let _ranks = ranks.filter((rank)=>{
        return rank.id == id;
			})
			if(_ranks.length != 0){
        return _ranks[0];
			}
			return false;
		}

	});

	return PosDB;

});
