odoo.define('ev_pos_loyalty_ui.models', function(require){
	"use strict"

	const models = require('point_of_sale.models');


	models.load_fields('res.partner', 
		['x_rank_id', 'loyalty_points', 'x_date_rank']
	);

	models.load_models([{
    model: 'customer.rank',
		label: 'Customer rank',
		fields: ['name', 'code', 'discount', 'product_id', 'product_ids', 
			'categories_ids'],
		loaded: (self, res)=>{
      self.db.saveCustomerRanks(res);
		}
	}]);
	

	return models;

});
