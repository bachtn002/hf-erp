odoo.define('ev_pos_loyalty_ui.Orderline', function(require){
	"use strict"

	const models = require('point_of_sale.models');

	var Orderline = models.Orderline;
	models.Orderline = models.Orderline.extend({
    getIsRankDiscount: function(){
      return this.is_rank_discount;
		},

		setIsRankDiscount: function(is_rank_discount){
      this.is_rank_discount = is_rank_discount;
		},

		init_from_JSON: function(json){
      Orderline.prototype.init_from_JSON.apply(this, arguments);
			this.is_rank_discount = json.is_rank_discount;
		},

		export_as_JSON: function(){
      let res = Orderline.prototype.export_as_JSON.apply(this, arguments);

			res.is_rank_discount = this.getIsRankDiscount();

			return res;

		}

	});

	return models;

});
