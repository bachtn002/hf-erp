odoo.define('ev_pos_loyalti_ui.DiscountByRank', function(require){
	"use strict"

	const PosComponent = require('point_of_sale.PosComponent');

	const Registries = require('point_of_sale.Registries');
	

	class DiscountByRank extends PosComponent{

		_onClick(ev){
			ev.preventDefault();
      this.trigger('discount-by-rank');
		}

	};
	DiscountByRank.template = 'DiscountByRank';
  
	Registries.Component.add(DiscountByRank);

  return DiscountByRank;

});
