odoo.define('ev_pos_loyalty_ui.ProductScreen', function(require){
	"use strict"

	const core = require('web.core');
	const ProductScreen = require('point_of_sale.ProductScreen');
	const Registries = require('point_of_sale.Registries');

	const { useState } = owl.hooks;
	const { useListener } = require('web.custom_hooks');

	const _t = core._t;


	let LoyaltyProductScreen = ProductScreen => 
		class extends ProductScreen {

			/**
			 * [Inheritant] constructor.
			 */
			constructor(){
				super(...arguments);
				this.refreshLoyaltyView();
				this.discountByRank(true);
				useListener('discount-by-rank', this._onClickDiscountByRank);
			}

			_onClickDiscountByRank(event){
				this.discountByRank();		
			}

			discountByRank(init=false){
				if(init && !this.hasDiscountByRank())
          return;
				this.clearProductRankDiscount();
				let order = this.env.pos.get_order();
				let client = order.get_client();
				if(!client)
					return;

				let rank = false;
				if(client.x_rank_id)
					rank = this.env.pos.db.getCustomerRankById(client.x_rank_id[0]);
				if(!rank)
					return;

				let product = this.env.pos.db.get_product_by_id(rank.product_id[0]);
				let totalValueHasDiscount = 0;
				let productIds = rank.product_ids;
				let categIds = rank.categories_ids;
				let check = productIds.length > 0 || categIds.length > 0;
				order.orderlines.forEach((line)=>{
					if(!check || 
						_.indexOf(productIds, line.product.id) === -1 &&
						_.indexOf(categIds, line.product.pos_categ_id[0]) === -1){
						totalValueHasDiscount += line.get_display_price();
					}
				});
				let price = totalValueHasDiscount * rank.discount / 100;
				if(price === 0)
					return;
				order.add_product(product, {
					price: price * -1,
					quantity: 1,
					extras: {
						is_rank_discount: true
					}
				});

			}

			clearProductRankDiscount(){
				let order = this.env.pos.get_order();
				let discountLine = order.orderlines.filter((item)=>{
					return item.is_rank_discount;
				});
				if(discountLine.length == 0)
					return;
				discountLine.forEach((line)=>{
					order.remove_orderline(line);
				});
			}

      hasDiscountByRank(){
        let order = this.env.pos.get_order();
				let discounted = order.orderlines.filter((line)=>{
          return line.is_rank_discount;
				});
				return discounted.length > 0;
			}

			refreshLoyaltyView(){
				if(!this.state.updateLoyalty){
					this.state.updateLoyalty = 1;
				} else {
					this.state.updateLoyalty += 1;
				}
			}

			async _clickProduct(event){
				super._clickProduct(event);
				this.refreshLoyaltyView();
			}

			async _onClickCustomer(){
				super._onClickCustomer();
				this.refreshLoyaltyView();
			}

			async _updateSelectedOrderline(event){
				super._updateSelectedOrderline(event);
				this.refreshLoyaltyView();
			}

			async _newOrderlineSelected(event){
				super._newOrderlineSelected(event);
				this.refreshLoyaltyView();
			}

		};

	Registries.Component.extend(ProductScreen, LoyaltyProductScreen);

	return ProductScreen;

});
