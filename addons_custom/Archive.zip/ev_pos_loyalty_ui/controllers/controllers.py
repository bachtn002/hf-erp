# -*- coding: utf-8 -*-
# from odoo import http


# class EvPosLoyaltyUi(http.Controller):
#     @http.route('/ev_pos_loyalty_ui/ev_pos_loyalty_ui/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/ev_pos_loyalty_ui/ev_pos_loyalty_ui/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('ev_pos_loyalty_ui.listing', {
#             'root': '/ev_pos_loyalty_ui/ev_pos_loyalty_ui',
#             'objects': http.request.env['ev_pos_loyalty_ui.ev_pos_loyalty_ui'].search([]),
#         })

#     @http.route('/ev_pos_loyalty_ui/ev_pos_loyalty_ui/objects/<model("ev_pos_loyalty_ui.ev_pos_loyalty_ui"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('ev_pos_loyalty_ui.object', {
#             'object': obj
#         })
