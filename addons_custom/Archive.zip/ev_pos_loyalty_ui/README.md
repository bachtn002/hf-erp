# IZI Pos Loyalty UI

Module folder name: ev_pos_loyalty_ui