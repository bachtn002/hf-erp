# -*- coding: utf-8 -*-

from . import mailmerge
from . import ir_actions_report
