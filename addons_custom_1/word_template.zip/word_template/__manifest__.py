# -*- coding: utf-8 -*-
{
    'name': "Docx Report",

    'summary': """
        Use MS Word template to design reports""",
    'description': """
        Use ms word template to design reports
    """,
    'category': 'Tools',
    'author': "ERPViet",
    'version': '14.0.6',
    'depends': ['base'],
    'data': [
        'views/ir_actions_report_views.xml',
    ],
}
